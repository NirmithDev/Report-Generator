Program Author: Nirmith Victor D'Almeida
Student ID number: 101160124

Purpose: 
Create a menu like option that access data from a farms.dat file and prints out data according to the user's choice from menu

List of cc files Included:
1. main.cc
2. View.cc
3. Control.cc
4. Record.cc
5. Report1.cc
6. Report2.cc
7. Report3.cc
8. ReportGenerator.cc 

List of h files included (inclusive of class templates):
 1. AscBehaviour.h
 2. CompareBehaviour.h
 3. Control.h
 4. DescBehaviour.h
 5. Map.h
 6. Record.h
 7. Report1.h
 8. Report2.h
 9. Report3.h
10. ReportData.h
11. ReportGenerator.h
12. View.h

Separate files included:
1. README.txt
2. UMLDiagram_PROJECT.pdf
3. farms.dat
4. Makefile

--- How to use the code:
-> after extracting the code and saving it to a folder of choice
-> go to terminal and type
	-> make
	->and then type ./project or valgrind project
	
	
----Known leaks and issues
-> at the moment there is only a single leak that occurs whenever Report 2 is run 
-> I think it is the way I am handling the missing wild boar case in the year 2016 
-> sadly I have run out of time to work and fix this issue since my exams are going to start soon but apart from that the code functions well to meet the requirements
