#include <iostream>
using namespace std;
#include <string>

#include "Control.h"

int main(){
	
	Control c;
	c.launch();
	return 0;
}

